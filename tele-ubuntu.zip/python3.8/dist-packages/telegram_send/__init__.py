from .version import __version__
from .telegram_send import configure, send


__all__ = ["configure", "send"]
